/* global app */
'use strict';
WidgetConfig = {
        analogicMain:
            {
                id: 'analogicMain',
                type: PageWidget,
                widgets: [
                    {
                        id: 'analogicMainHelloAnalogic',
                        type: TextWidget,
                        title: 'Hello world'
                    }
                ]
            }
};